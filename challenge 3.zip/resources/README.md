###1
calculate the votes of each county and who won
###2a
369,711
###2b
Jefferson : 38,355 10.5%
Denver: 306,055 82.8%
Arapahoe:24,801 6.7%
###2c
Denver
###2d
Charles Casper Stockham: 23.0% (85,213)
Diana DeGette: 73.8% (272,892)
Raymon Anthony Doane: 3.1% (11,606)
###2e
Diana DeGette,272892,73.8%
###3
filter it by election type and filter winners by county